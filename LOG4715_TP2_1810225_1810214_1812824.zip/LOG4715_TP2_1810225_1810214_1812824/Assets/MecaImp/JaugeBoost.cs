using UnityEngine;
using UnityEngine.UI;

public class JaugeBoost : MonoBehaviour
{
	public Texture2D cadranBoost ;
	public Texture2D aiguilleBoost ;
	private Vector2 pivotPoint;
	EtatVoiture etat;
	float boost;
	float boostMax;

	void Start () {
		GameObject player = GameObject.Find("Joueur 1");
		etat = player.GetComponent<EtatVoiture> ();
		boostMax = etat.Boost;
	}

	void Update () {
		boost = etat.Boost;
	}
	
	void OnGUI() {
		GUI.DrawTexture(new Rect(Screen.width - 150,Screen.height - 250,150,75),cadranBoost);
		float facteurBoost = boost / boostMax;
		float angleRotation = Mathf.Lerp (0, 180, facteurBoost);

		angleRotation = Mathf.Lerp(0,180,facteurBoost);
		
		pivotPoint = new Vector2 (Screen.width - 75, Screen.height - 175);
		GUIUtility.RotateAroundPivot (angleRotation, pivotPoint);
		GUI.DrawTexture(new Rect(Screen.width - 150,Screen.height - 250,150,150),aiguilleBoost);
	}
}