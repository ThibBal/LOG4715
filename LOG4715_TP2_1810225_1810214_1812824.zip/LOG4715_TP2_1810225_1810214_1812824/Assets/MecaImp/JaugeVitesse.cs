using UnityEngine;
using UnityEngine.UI;

public class JaugeVitesse : MonoBehaviour {
	
	public Texture2D cadranVitesse ;
	public Texture2D aiguilleVitesse ;
	private Vector2 pivotPoint;
	CarController carController;
	
	float vitesse;
	float vitesseMax;

	void Start () {
		GameObject player = GameObject.Find("Joueur 1");
		carController = player.GetComponent<CarController> ();
		vitesseMax = carController.MaxSpeed;
	}

	void Update () {
		vitesse = carController.CurrentSpeed;
	}

	//Affichage du cadran avec une aiguille pour le compteur vitesse. 
	//Source: https://www.youtube.com/watch?v=UbzbYDhJQRQ
	void OnGUI() {

		GUI.DrawTexture(new Rect(Screen.width - 300,Screen.height - 175,300,150),cadranVitesse);
		float facteurVitesse = vitesse / vitesseMax;
		float angleRotation = Mathf.Lerp (0, 180, facteurVitesse);

		if (vitesse >= 0){
			angleRotation = Mathf.Lerp(0,180,facteurVitesse);
		} else {
			angleRotation = Mathf.Lerp(0,180,-facteurVitesse);
		}

		pivotPoint = new Vector2 (Screen.width - 150, Screen.height - 25);
		GUIUtility.RotateAroundPivot (angleRotation, pivotPoint);
		GUI.DrawTexture(new Rect(Screen.width - 300,Screen.height - 175,300,300),aiguilleVitesse);

	}
}