using UnityEngine;
using System.Collections;

public class Replacement : MonoBehaviour {

	[SerializeField] private int perteScoreReplacement = -300; 
	[SerializeField] private int pertePVReplacement = -5; 
	
	public string tag = "Player";
	
	public Transform replacementPoint;

	void OnTriggerEnter(Collider collider) {
		Transform car = collider.transform.parent.parent;
		if (car.tag == tag) {
			car.position = replacementPoint.position;
			car.rotation = replacementPoint.rotation;
			car.rigidbody.velocity = Vector3.zero;
			car.GetComponent<EtatVoiture>().changerScore(perteScoreReplacement);
			car.GetComponent<EtatVoiture>().changerPV(pertePVReplacement);
		}
	}
}