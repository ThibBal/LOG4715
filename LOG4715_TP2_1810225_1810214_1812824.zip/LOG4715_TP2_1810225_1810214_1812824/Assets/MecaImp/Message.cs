using UnityEngine;
using System.Collections;

public class Message : MonoBehaviour 
{
	[SerializeField]
	private GUIText message;
	
	void Update () {
		message.text = getMessage();
	}
	
	public string getMessage() {
		CarController car = transform.GetComponent<CarController> ();
		if (!car.anyOnGround) {
			return "Saut !";
		}

		if (car.estCrashé) {
			car.estCrashé = false;
			return "Crash avec " + car.crashAvec + " !";
		}

		if (car.estFrolé) {
			car.estFrolé = false;
			return "Frolage avec " + car.voitureFrolée + " !";
		}

		return "";
	}
}